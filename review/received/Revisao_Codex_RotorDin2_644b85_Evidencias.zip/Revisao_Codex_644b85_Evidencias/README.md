# Evidências da revisão independente — 644b85a7

Leia `REVISAO.md` e `verification/review_summary.json`.

## O que foi feito

O histórico entregue foi restaurado, os manifestos verificados e a suíte do autor executada integralmente em Linux/GNU Fortran 14.2.0. Os controles fornecidos passaram (18 agregados, incluindo ST41 com 25 grupos disponíveis). Novos testes independentes encontraram dois defeitos de grade temporal/publicação, detalhados no relatório. Não houve alteração de fonte/commit/push/merge.

`supplied_suite/` e `directed_results/` contêm registros desta revisão, não cópias que simulam uma nova execução. Há um subconjunto compacto de logs da suíte: os grandes históricos e binários são reconstruíveis e foram omitidos. Caminhos absolutos nos logs identificam o ambiente real em que foram gerados; não precisam existir para interpretar as saídas.

## Reproduzir os novos testes

Pré-requisitos: GNU/Linux ou WSL, bash, make, GNU Fortran, Python 3, utilitário `timeout`, checkout Git restaurado a partir do bundle do ZIP original. NumPy/SciPy são necessários para a suíte original, mas não para o verificador dos novos contracasos.

```sh
FC=gfortran bash run_directed_review.sh /caminho/checkout /caminho/saida-nova
```

O script confere o HEAD, compila Release/Debug e executa o núcleo real e três entradas de CLI. Também compila um controle substituindo somente `tnuinteg.f90` pelo baseline. Não sobrescreve fontes nem altera o Git. Usa as bibliotecas e objetos do próprio projeto.

**O retorno esperado no SHA auditado é 1 (FAIL das condições matemáticas).** Os processos nativos retornam 0 mesmo quando publicam resultados errados; o verificador não utiliza isso como aprovação. Erro de infraestrutura/parsing não é aprovação e retorna 2. Uma interrupção no build preserva seu erro nativo.

`portable_reproduction/` contém a execução efetiva desse script pelo revisor.

Para testar deliberadamente um SHA futuro, é possível usar `ALLOW_OTHER_HEAD=1`. Isso não dispensa revisar as expectativas e qualificar o novo resultado. Não use uma pasta de evidência já existente.

## Integridade

```sh
sha256sum -c SHA256SUMS.txt
```

O manifesto não inclui a si próprio. Não há fontes de tipografia, livros, imagens de livros ou binários de produção no pacote.
