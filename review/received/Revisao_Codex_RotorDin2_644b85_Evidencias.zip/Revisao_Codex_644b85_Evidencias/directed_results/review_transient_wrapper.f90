! Production assembly -> eigenproblem -> tprptran -> tnuinteg -> native output.
! No physics/printing stubs. Two-node Kelvin-Voigt coupling, one constant torque.
program review_transient_wrapper
  use rd_kinds, only: wp
  use com_sec, only: nt,nn,y,n
  use com_sea, only: rs,gs,ie,dely
  use com_sed, only: ds
  use com_eix, only: ps
  use com_eqvlen, only: tsl
  use com_couplings, only: ncplg,cplgid,cplgst,cplgin,cplgdp,cplgsr
  use com_conc, only: nmic
  use com_dis, only: nd
  use com_tman, only: ntbr
  use com_unb0, only: np,pr,nm
  use com_unb1, only: nb,ndd,mu,ed,tpf
  use com_mdampso, only: mdoff
  use com_mdamps, only: ntdmp
  use com_ttransc, only: ttris,ttrrs,ttrit,ttret
  use com_ttransd, only: ttrmd,ttrdtt,ttrdta,nttra,ttrdsz,iseqt
  use com_mdd, only: porb
  use com_sta, only: stm
  implicit none
  integer::ok,pdm,i
  character(len=99)::msg
  character(len=20)::arg
  call get_command_argument(1,arg)
  nt=2;nn=1;y=0._wp;y(2)=1._wp;n=0._wp;n(1)=1._wp
  ps=0._wp;ps(1)=1._wp
  gs=1._wp;rs=1._wp;ie=.5_wp;dely=1._wp;tsl=0._wp;ds=1._wp
  nmic=0;nd=0;ntbr=0;ncplg=1;cplgid(1)=1
  cplgst(1)=100._wp;cplgin(1)=.3_wp;cplgdp(1)=4._wp;cplgsr(1)=1._wp
  stm='INDEPENDENT_TPRPTRAN_OUTPUT_REVIEW'; msg=''
  call tmatrices(1,pdm,msg,ok)
  if(ok/=0) then
    print *,trim(msg);stop 1
  endif
  call tespmod(msg,ok)
  if(ok/=0) then
    print *,trim(msg);stop 1
  endif
  ntdmp=0;mdoff=0
  call tmdamp_checked(msg,ok)
  if(ok/=0) then
    print *,trim(msg);stop 1
  endif
  np=1;pr(1)=1._wp;nm=4;nb=1;ndd(1)=1._wp;mu(1)=1._wp;ed(1)=0._wp;tpf(1)=-1
  porb=1._wp;nttra=1;ttrdsz=5;iseqt=.false.
  ttrmd=0._wp;ttris=0._wp;ttrrs=0._wp;ttrit=0._wp;ttret=0._wp
  do i=1,5
    ttrdtt(i)=real(i-1,wp)*.004_wp;ttrdta(1,i)=1._wp
  enddo
  if(trim(arg)=='explicit_output') ttrrs=.001_wp
  call tprptran(1,.true.,.true.,.false.,msg,ok)
  write(*,'(a,a,a,i0,1x,a)') 'WRAPPER_CASE=',trim(arg),' OK=',ok,trim(msg)
end program
